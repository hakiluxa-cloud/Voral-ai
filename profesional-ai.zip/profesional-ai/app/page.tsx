"use client";

import { useEffect, useRef, useState } from "react";

type Msg = { role: "user" | "assistant"; content: string };

const FREE_MODELS = [
  { id: "meta-llama/llama-3.1-8b-instruct:free", label: "Llama 3.1 8B (gratis)" },
  { id: "google/gemma-2-9b-it:free", label: "Gemma 2 9B (gratis)" },
  { id: "mistralai/mistral-7b-instruct:free", label: "Mistral 7B (gratis)" },
];

export default function Home() {
  const [apiKey, setApiKey] = useState("");
  const [keySaved, setKeySaved] = useState(false);
  const [model, setModel] = useState(FREE_MODELS[0].id);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  // Load saved key from this browser only — never sent anywhere except
  // directly to our own /api/chat route, which forwards it to OpenRouter.
  useEffect(() => {
    const saved = localStorage.getItem("openrouter_key");
    if (saved) {
      setApiKey(saved);
      setKeySaved(true);
    }
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  function saveKey() {
    localStorage.setItem("openrouter_key", apiKey);
    setKeySaved(true);
  }

  function clearKey() {
    localStorage.removeItem("openrouter_key");
    setApiKey("");
    setKeySaved(false);
  }

  async function sendMessage() {
    if (!input.trim() || loading) return;
    if (!apiKey) {
      setError("Isi API key OpenRouter kamu dulu di atas.");
      return;
    }

    const newMessages: Msg[] = [...messages, { role: "user", content: input }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-openrouter-key": apiKey,
        },
        body: JSON.stringify({ model, messages: newMessages }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Terjadi kesalahan.");
        setLoading(false);
        return;
      }

      const reply = data.choices?.[0]?.message?.content ?? "(kosong)";
      setMessages([...newMessages, { role: "assistant", content: reply }]);
    } catch {
      setError("Gagal menghubungi server.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen flex flex-col max-w-2xl mx-auto px-4 py-6">
      <h1 className="text-xl font-semibold mb-4">Profesional AI</h1>

      {/* API key section */}
      <div className="mb-4 p-3 rounded-lg border border-white/10 bg-white/5">
        <label className="text-sm text-white/70 block mb-2">
          API Key OpenRouter kamu (disimpan di browser ini saja)
        </label>
        <div className="flex gap-2">
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="sk-or-v1-..."
            className="flex-1 rounded-md bg-black/40 border border-white/10 px-3 py-2 text-sm outline-none"
          />
          {keySaved ? (
            <button
              onClick={clearKey}
              className="px-3 py-2 text-sm rounded-md bg-red-500/20 border border-red-500/30"
            >
              Hapus
            </button>
          ) : (
            <button
              onClick={saveKey}
              className="px-3 py-2 text-sm rounded-md bg-emerald-500/20 border border-emerald-500/30"
            >
              Simpan
            </button>
          )}
        </div>
        <p className="text-xs text-white/40 mt-2">
          Belum punya key? Buat gratis di{" "}
          <a
            href="https://openrouter.ai/keys"
            target="_blank"
            className="underline"
          >
            openrouter.ai/keys
          </a>
        </p>
      </div>

      {/* Model picker */}
      <div className="mb-4">
        <label className="text-sm text-white/70 block mb-1">Model</label>
        <select
          value={model}
          onChange={(e) => setModel(e.target.value)}
          className="w-full rounded-md bg-black/40 border border-white/10 px-3 py-2 text-sm outline-none"
        >
          {FREE_MODELS.map((m) => (
            <option key={m.id} value={m.id}>
              {m.label}
            </option>
          ))}
        </select>
      </div>

      {/* Chat log */}
      <div className="flex-1 overflow-y-auto space-y-3 mb-4 min-h-[300px]">
        {messages.map((m, i) => (
          <div
            key={i}
            className={`p-3 rounded-lg text-sm whitespace-pre-wrap ${
              m.role === "user"
                ? "bg-blue-500/20 ml-8"
                : "bg-white/5 mr-8"
            }`}
          >
            {m.content}
          </div>
        ))}
        {loading && (
          <div className="p-3 rounded-lg text-sm bg-white/5 mr-8 text-white/50">
            Mengetik...
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {error && (
        <p className="text-sm text-red-400 mb-2">{error}</p>
      )}

      {/* Input */}
      <div className="flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder="Ketik pesan..."
          className="flex-1 rounded-md bg-black/40 border border-white/10 px-3 py-2 text-sm outline-none"
        />
        <button
          onClick={sendMessage}
          disabled={loading}
          className="px-4 py-2 text-sm rounded-md bg-blue-500/30 border border-blue-500/40 disabled:opacity-50"
        >
          Kirim
        </button>
      </div>
    </main>
  );
}
