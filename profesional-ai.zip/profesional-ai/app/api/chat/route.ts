import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

// --- Simple in-memory rate limiter (best-effort; resets on cold start) ---
// For production-grade limiting across serverless instances, swap this for
// a shared store like Upstash Redis. This is enough to stop casual abuse.
const RATE_LIMIT = 20; // max requests
const WINDOW_MS = 60 * 1000; // per 60 seconds
const buckets = new Map<string, { count: number; resetAt: number }>();

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const bucket = buckets.get(ip);

  if (!bucket || now > bucket.resetAt) {
    buckets.set(ip, { count: 1, resetAt: now + WINDOW_MS });
    return false;
  }

  if (bucket.count >= RATE_LIMIT) {
    return true;
  }

  bucket.count += 1;
  return false;
}

export async function POST(req: NextRequest) {
  // Identify caller for rate limiting purposes
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    req.headers.get("x-real-ip") ??
    "unknown";

  if (isRateLimited(ip)) {
    return NextResponse.json(
      { error: "Terlalu banyak request. Coba lagi sebentar lagi." },
      { status: 429 }
    );
  }

  // The user's own OpenRouter API key, sent from the browser per request.
  // We never store this server-side — it's forwarded straight through.
  const apiKey = req.headers.get("x-openrouter-key");

  if (!apiKey) {
    return NextResponse.json(
      { error: "API key OpenRouter belum diisi." },
      { status: 400 }
    );
  }

  let body: { messages?: unknown; model?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { error: "Body request tidak valid." },
      { status: 400 }
    );
  }

  const { messages, model } = body;

  if (!Array.isArray(messages) || messages.length === 0) {
    return NextResponse.json(
      { error: "Field 'messages' wajib diisi." },
      { status: 400 }
    );
  }

  try {
    const upstream = await fetch(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
          // OpenRouter asks for these to attribute traffic; harmless to include.
          "HTTP-Referer": req.headers.get("origin") ?? "https://profesional-ai.vercel.app",
          "X-Title": "Profesional AI",
        },
        body: JSON.stringify({
          model: model || "meta-llama/llama-3.1-8b-instruct:free",
          messages,
        }),
      }
    );

    const data = await upstream.json();

    if (!upstream.ok) {
      return NextResponse.json(
        { error: data?.error?.message || "OpenRouter menolak request." },
        { status: upstream.status }
      );
    }

    return NextResponse.json(data);
  } catch (err) {
    return NextResponse.json(
      { error: "Gagal menghubungi OpenRouter. Coba lagi." },
      { status: 502 }
    );
  }
}
