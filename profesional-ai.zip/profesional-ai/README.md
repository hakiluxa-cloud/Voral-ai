# Profesional AI

Chat AI sederhana pakai Next.js + OpenRouter, dengan sistem **BYOK (Bring Your Own Key)** —
setiap user masukin API key OpenRouter mereka sendiri, disimpan di browser masing-masing
(localStorage). Server (`/api/chat`) cuma jadi jembatan/proxy dan tidak pernah menyimpan key siapa pun.

## Kenapa BYOK?

Kalau app publik pakai satu API key yang lo simpan sendiri di server, kredit lo bisa cepat
habis dipakai orang lain. Dengan BYOK, setiap orang pakai kuota/kredit API key mereka sendiri —
lo cuma nyediain aplikasinya.

## Jalanin di lokal

```bash
npm install
npm run dev
```

Buka http://localhost:3000

## Deploy ke Vercel

1. Push folder ini ke GitHub repo baru
2. Buka [vercel.com](https://vercel.com) → **New Project** → import repo tersebut
3. Vercel otomatis detect Next.js, tinggal klik **Deploy**
4. Tidak perlu environment variable apa pun di Vercel, karena API key dimasukkan oleh
   masing-masing user langsung di browser mereka

## Cara pakai

1. Buka situsnya
2. Buat API key gratis di [openrouter.ai/keys](https://openrouter.ai/keys)
3. Paste key itu di kolom "API Key OpenRouter" → klik **Simpan**
4. Pilih model gratis, mulai chat

## Keamanan

- API key **tidak pernah** disimpan di server/database — hanya di `localStorage` browser user
- Setiap request dari browser mengirim key lewat header `x-openrouter-key`, langsung
  diteruskan ke OpenRouter oleh `/api/chat`, tidak dicatat/di-log
- Ada rate limiting sederhana (20 request/menit per IP) di `/api/chat/route.ts` untuk
  mencegah spam ke endpoint

## Struktur project

```
app/
  page.tsx           -> UI chat + input API key
  api/chat/route.ts  -> proxy ke OpenRouter API + rate limiting
  layout.tsx
  globals.css
```

## Upgrade selanjutnya (opsional)

- Ganti rate limiter in-memory dengan Upstash Redis biar konsisten di semua instance serverless
- Tambah lebih banyak pilihan model (termasuk model berbayar) di `FREE_MODELS`
- Tambah riwayat percakapan tersimpan (localStorage atau database)
